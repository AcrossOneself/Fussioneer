function print_me() {
  
  for (let i = 0; i < arguments.length; i++) {
    console.log(arguments[i]);
  }

}

print_me('foo'); 
// foo

print_me('foo', 'bar'); 
//foo
//bar