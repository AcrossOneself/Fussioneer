function print_me() {
  
  let values = [];

  for (let i = 0; i < arguments.length; i++) {
    values.push(arguments[i]);
  }

  let valuesFlat= [].concat.apply([], values);
  
  for (let i = 0; i < valuesFlat.length; i++) {
    console.log(valuesFlat[i]);
  }
}

print_me('foo', ['bar', 'baz']);
// "foo"
// "bar"
// "baz"