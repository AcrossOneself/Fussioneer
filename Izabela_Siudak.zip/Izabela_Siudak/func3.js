function print_me(x) {
	return function helper(y) {
  	console.log(x);
    console.log(y);
  }
}
   
print_me('foo')('bar');